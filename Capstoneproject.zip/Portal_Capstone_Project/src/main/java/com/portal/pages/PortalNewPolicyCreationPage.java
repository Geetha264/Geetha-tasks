package com.portal.pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PortalNewPolicyCreationPage extends PortalDashBoardPage {

    String InputField="//label[text()='@@']/following-sibling::input";


    private final By policyTypeDropDownLocator=By.id("policy_type");
    private final By ageInputFieldLocator=By.xpath(InputField.replace("@@","Age"));
    private final By durationFieldLocator=By.xpath(InputField.replace("@@","Duration (Years)"));
    private final By submitLocator=By.xpath("//button[text()='Submit']");


    public PortalNewPolicyCreationPage(WebDriver driver) {
        super(driver);
    }

    public boolean createNewPolicy(String PolicyName,String age,String Duration){
        int countOfPoliciesBeforeCreation=Integer.parseInt(getPoliciesText());

        createPolicyNavigation();
        selectByVisibleText(policyTypeDropDownLocator,PolicyName);

        WebElement ageField=getElement(ageInputFieldLocator);
        ageField.clear();
        ageField.sendKeys(age);

        WebElement DurationField=getElement(durationFieldLocator);
        DurationField.clear();
        DurationField.sendKeys(Duration);

        WebElement submitButton=getElement(submitLocator);
        submitButton.click();

        dashBoardNavigation();
        if (Integer.parseInt(getPoliciesText())>countOfPoliciesBeforeCreation){
            return  true;
        }else{
            return false;
        }


    }



}
