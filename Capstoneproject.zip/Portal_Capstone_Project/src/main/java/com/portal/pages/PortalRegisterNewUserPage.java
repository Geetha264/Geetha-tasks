package com.portal.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Full-featured Register page object with helper methods for tests.
 * Drop this file into com.project.pages and use it from your TestNG tests.
 *
 * NOTE: This class assumes PaymentPage provides:
 *   - protected WebDriver driver (or getDriver())
 *   - protected WebElement getElement(By locator)
 *   - optionally getCurrentTimeWithMillis() (fallback implemented below)
 *
 * If your PaymentPage has differently named helpers, adapt calls accordingly.
 */
public class PortalRegisterNewUserPage extends PortalPaymentPage {

    // --- XPaths / Locators --- (adjust if your UI differs)
    private final String AccountCreationInputFields = "//label[normalize-space(text())='@@']/following-sibling::input";
    private final By CreateRegister = By.xpath("//a[normalize-space(text())='Register' or @id='register-link']");
    private final By UsernameFieldLocator = By.xpath(AccountCreationInputFields.replace("@@", "Username:"));
    private final By EmailFieldLocator = By.xpath(AccountCreationInputFields.replace("@@", "Email address:"));
    private final By PasswordFieldLocator = By.xpath(AccountCreationInputFields.replace("@@", "Password:"));
    private final By PasswordConfirmationLocator = By.xpath(AccountCreationInputFields.replace("@@", "Password confirmation:"));
    private final By SubmitClickLocator = By.xpath("//button[normalize-space(text())='Register']");
    private final By AccountCreationMessageLocator = By.xpath("//div[contains(text(),'Account created successfully') or contains(text(),'Account created successfully! Redirecting')]");
    // Generic inline validation message for a field label (change if needed)
    private final String InlineValidationXpath = "//label[contains(text(),'@@')]/following-sibling::div";
    // Duplicate / already exists message (adjust text)
    private final By AlreadyExistsMessageLocator = By.xpath("//div[contains(text(),'Email already in use.')]");

    public PortalRegisterNewUserPage(WebDriver driver) {
        super(driver);
    }

    // ---------- Basic interactions ----------
    public void openRegister() {
        WebElement registerLink = getElement(CreateRegister);
        registerLink.click();
        // optionally wait for form visible - caller can add explicit wait if needed
    }

    public void fillUsername(String username) {
        getElement(UsernameFieldLocator).clear();
        getElement(UsernameFieldLocator).sendKeys(username);
    }

    public void fillEmail(String email) {
        getElement(EmailFieldLocator).clear();
        getElement(EmailFieldLocator).sendKeys(email);
    }

    public void fillPassword(String password) {
        getElement(PasswordFieldLocator).clear();
        getElement(PasswordFieldLocator).sendKeys(password);
    }

    public void fillConfirmPassword(String password) {
        getElement(PasswordConfirmationLocator).clear();
        getElement(PasswordConfirmationLocator).sendKeys(password);
    }

    public void clickSubmit() {
        getElement(SubmitClickLocator).click();
    }

    // Returns true when success popup/message is displayed
    public boolean isAccountCreationMessageDisplayed() {
        try {
            WebElement msg = getElement(AccountCreationMessageLocator);
            return msg.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    // ---------- Composite flows ----------

    /**
     * Happy path: fill all fields and submit.
     * Returns true if success message appears.
     */
    public boolean registerNewCustomer(String username, String email, String password) {
        openRegister();
        fillUsername(username);
        fillEmail(email);
        fillPassword(password);
        fillConfirmPassword(password);
        clickSubmit();
        return isAccountCreationMessageDisplayed();
    }

    /**
     * Fill form with given values and submit.
     * Returns true when any inline validation message was detected for any field.
     */
    public boolean registerAndReturnIfValidationError(String username, String email, String password, String confirmPassword) {
        openRegister();
        fillUsername(username);
        fillEmail(email);
        fillPassword(password);
        fillConfirmPassword(confirmPassword);
        clickSubmit();

        // check for any known inline validation near labels
        boolean usernameErr = isValidationMessageDisplayedFor("Username:");
        boolean emailErr = isValidationMessageDisplayedFor("Email address:");
        boolean passwordErr = isValidationMessageDisplayedFor("Password:");
        boolean confirmErr = isValidationMessageDisplayedFor("Password confirmation:");

        // also check already exists message
        boolean alreadyExists = isAlreadyExistsMessageDisplayed();

        return usernameErr || emailErr || passwordErr || confirmErr || alreadyExists;
    }

    /**
     * Click submit without filling any fields and return true if validation messages are shown.
     */
    public boolean clickSubmitWithoutFillingAndDetectValidation() {
        openRegister();
        clickSubmit();
        boolean usernameErr = isValidationMessageDisplayedFor("Username:");
        boolean emailErr = isValidationMessageDisplayedFor("Email address:");
        boolean passwordErr = isValidationMessageDisplayedFor("Password:");
        boolean confirmErr = isValidationMessageDisplayedFor("Password confirmation:");
        return usernameErr || emailErr || passwordErr || confirmErr;
    }

    /**
     * Try registering using an email already used. Returns true if duplicate/already-exists message is shown.
     * Use this after creating the first account with that email.
     */
    public boolean registerAndReturnIfAlreadyExists(String username, String email, String password) throws InterruptedException {
        openRegister();
        fillUsername(username);
        fillEmail(email);
        fillPassword(password);
        fillConfirmPassword(password);
        clickSubmit();
        Thread.sleep(3000);
        // Wait briefly or implement explicit wait in getElement if needed
        return isAlreadyExistsMessageDisplayed();
    }

    // ---------- Small helpers ----------
    public boolean isValidationMessageDisplayedFor(String fieldLabelExactText) {
        try {
            By xpath = By.xpath(InlineValidationXpath.replace("@@", fieldLabelExactText));
            WebElement err = getElement(xpath);
            return err != null && err.isDisplayed();
        } catch (Exception e) {
            // fallback: search for visible elements with "required" or "invalid" text near the input
            try {
                // try near input element
                By inputXpath = By.xpath(AccountCreationInputFields.replace("@@", fieldLabelExactText));
                WebElement input = getElement(inputXpath);
                // look for following sibling nodes
                String altXpath = ".//following-sibling::*[contains(text(),'required') or contains(text(),'invalid') or contains(text(),'Please') or contains(text(),'must') or contains(text(),'mismatch')]";
                List<WebElement> candidates = input.findElements(By.xpath(altXpath));
                for (WebElement c : candidates) {
                    if (c.isDisplayed()) return true;
                }
            } catch (Exception ignore) {
            }
            return false;
        }
    }

    public boolean isAlreadyExistsMessageDisplayed() {
        try {
            WebElement el = getElement(AlreadyExistsMessageLocator);
            return el != null && el.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Small timestamp helper. If PaymentPage already has a more robust method, you can remove this.
     */
    public static String getCurrentTimeWithMillis() {
        try {
            // try to call parent implementation if exists
            // (if PaymentPage defines it, you can call super.getCurrentTimeWithMillis())
            // Fallback below:
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS")
                    .withZone(ZoneId.of("UTC"));
            return formatter.format(Instant.now());
        } catch (Exception e) {
            return String.valueOf(System.currentTimeMillis());
        }
    }
}