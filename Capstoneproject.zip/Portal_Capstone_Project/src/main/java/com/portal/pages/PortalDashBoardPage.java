package com.portal.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PortalDashBoardPage extends PortalLoginPage{

    String menuButtonLocator="//a[text()='@@']";
    String policyAndClaimsLocator="//h6[text()='@@']/following-sibling::h3";

    private final By createPolicyLocator=By.xpath(menuButtonLocator.replace("@@","New Policy"));
    private final By viewPolicyLocator=By.xpath(menuButtonLocator.replace("@@","View Policies"));
    private final By checkPremiumLocator=By.xpath(menuButtonLocator.replace("@@","Check Premium"));
    private final By viewClaimsLocator=By.xpath(menuButtonLocator.replace("@@","View Claims"));
    private final By dashBoardLocator=By.xpath(menuButtonLocator.replace("@@","Dashboard"));
    private final By logoutLocator=By.xpath(menuButtonLocator.replace("@@","Logout"));
    private final By totalPoliciesLocator=By.xpath(policyAndClaimsLocator.replace("@@","Policies"));
    private final By totalClaimsLocator=By.xpath(policyAndClaimsLocator.replace("@@","Claims"));
    public PortalDashBoardPage(WebDriver driver) {
        super(driver);
    }

    public void createPolicyNavigation(){
        getElement(createPolicyLocator).click();
    }

    public void viewPolicyNavigation(){
        getElement(viewPolicyLocator).click();
    }

    public void checkPremiumNavigation(){
        getElement(checkPremiumLocator).click();
    }

    public void viewClaimsNavigation(){
        getElement(viewClaimsLocator).click();
    }

    public  void dashBoardNavigation(){
        getElement(dashBoardLocator).click();
    }

    public void Logout(){
        getElement(logoutLocator).click();
    }

    public String getPoliciesText(){
        return getElement(totalPoliciesLocator).getText();
    }

    public  String getClaimsText(){
        return getElement(totalPoliciesLocator).getText();
    }
}
