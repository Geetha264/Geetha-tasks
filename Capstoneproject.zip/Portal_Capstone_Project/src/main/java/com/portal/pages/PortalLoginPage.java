package com.portal.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.portal.base.PortalBasePage;

public class PortalLoginPage extends PortalBasePage {

    // Locators
    private final By usernameField = By.id("username");
    private final By passwordField = By.id("password");
    private final By loginBtn = By.xpath("//button");
    private final By homeLoginClick=By.xpath("(//a[text()='Login'])[1]");
    private final By WelcomeText=By.xpath("//h2");

    //private By errorMsg = By.id("error-message");

    // Constructor
    public PortalLoginPage(WebDriver driver) {
        super(driver);
    }

    public void homePageLogin(){
        click(homeLoginClick);
    }

    public boolean isLoginButtonEnabled() {
        try { return getElement(loginBtn).isEnabled(); } catch (Exception e) { return false; }
    }

    public  void Login(String username,String password){
        getElement(usernameField).sendKeys(username);
        getElement(passwordField).sendKeys(password);
        getElement(loginBtn).click();
    }

    public boolean isLoginSuccessFull(){
        try {
            return driver.findElement(WelcomeText).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
