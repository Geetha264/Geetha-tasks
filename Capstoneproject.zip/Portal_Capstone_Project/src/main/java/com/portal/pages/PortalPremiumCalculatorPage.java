package com.portal.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PortalPremiumCalculatorPage extends PortalRegisterNewUserPage {

    private final By policyTypeLocator= By.name("policy_type");
    private final By ageLocator=By.name("age");
    private final By durationLocator=By.name("duration_years");
    private final By calculateLocator=By.xpath("//button[text()='Calculate']");
    private final By proceedToApplicationLocator=By.xpath("//a[text()='Proceed to Create Policy']");
    private final By premiumTextLocator=By.xpath("//h5");
    private final By coverageAmountTextLocator=By.xpath("//strong");


    public PortalPremiumCalculatorPage(WebDriver driver) {
        super(driver);
    }



    public boolean calculatePremium(String policyType,String age,String duration){

        checkPremiumNavigation();
        selectByVisibleText(policyTypeLocator,policyType);

        WebElement ageField=getElement(ageLocator);
        ageField.sendKeys(age);

        WebElement durationField=getElement(durationLocator);
        durationField.sendKeys(duration);

        WebElement calculateButton=getElement(calculateLocator);
        calculateButton.click();

        if(getElement(coverageAmountTextLocator).isDisplayed() && getElement(premiumTextLocator).isDisplayed()){
            System.out.println("premium calculated successfully");
        }

        return true;
    }

    public boolean calculatePremiumWithGreaterAge(String policyType, String age, String duration) {
        checkPremiumNavigation();
        selectByVisibleText(policyTypeLocator, policyType);

        WebElement ageField = getElement(ageLocator);
        ageField.clear();
        ageField.sendKeys(age);

        WebElement durationField = getElement(durationLocator);
        durationField.clear();
        durationField.sendKeys(duration);

        WebElement calculateButton = getElement(calculateLocator);
        calculateButton.click();

        try {
            boolean coverageVisible = getElement(coverageAmountTextLocator).isDisplayed();
            boolean premiumVisible = getElement(premiumTextLocator).isDisplayed();

            if (coverageVisible && premiumVisible) {
                System.out.println("Premium calculated successfully");
                return true;
            } else {
                System.out.println("Premium calculation failed: required elements not visible");
                return false;
            }
        } catch (Exception e) {
            System.out.println("Exception while calculating premium: " + e.getMessage());
            return false;
        }
    }

}
