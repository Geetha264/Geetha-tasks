package com.portal.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class PortalPaymentPage extends PortalNewPolicyCreationPage{

    String PaymentLocators="//td[contains(text(),'@@')]/following-sibling::td//span[contains(text(),'##')]//parent::td/following-sibling::td[@class='text-center align-middle']/a";

    private final By paidButtonLocator=By.xpath("//a[text()='Mark as Paid (Demo)']");
    private final By paymentCancelButton=By.xpath("//a[text()='Cancel']");
    private final By premiumAmountLocator=By.xpath("//p[text()='Premium to pay: ']/strong");




    public PortalPaymentPage(WebDriver driver) {
        super(driver);
    }

    public boolean payPremium(String PolicyName,String Status){
        By PaymentForInsurance=By.xpath(PaymentLocators.replace("@@",PolicyName).replace("##",Status));
        viewPolicyNavigation();
        //scrollIntoView(PaymentForInsurance);
        //((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", PaymentForInsurance);
        if(getElement(PaymentForInsurance).isDisplayed()){
            getElement(PaymentForInsurance).click();
        }
        if(getElement(premiumAmountLocator).isDisplayed()){
            getElement(paidButtonLocator).click();
        }else{
            getElement(paymentCancelButton).click();
        }
        return true;
    }
}
