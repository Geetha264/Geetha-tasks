package com.portal.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.*;

public class PortalClaimsAndRenewalPage extends PortalPremiumCalculatorPage {


    String createClaimLocator="//td[contains(text(),'@@')]/following-sibling::td//span[contains(text(),'##')]//parent::td/following-sibling::td/a";
    String policyStatus="//td[contains(text(),'@@')]/following-sibling::td/span";
    String renewalButtonLocator="//td[contains(text(),'@@')]/following-sibling::td//span[contains(text(),'##')]//parent::td/following-sibling::td[@class='text-center align-middle']/form/button";

    private final By coverageAmountLocator=By.name("claim_amount");
    private final By submitClaimLocator=By.xpath("//button[text()='Submit Claim']");
    private final By cancelClaimLocator=By.xpath("//button[text()='Cancel']");




    public PortalClaimsAndRenewalPage(WebDriver driver) {
        super(driver);
    }

    public boolean isUserAbleToRenewalPolicy(String policyType, String status) {
        By renewalButton = By.xpath(
                renewalButtonLocator.replace("@@", policyType).replace("##", status)
        );

        viewPolicyNavigation();

        try {
            List<WebElement> buttons = driver.findElements(renewalButton);
            if (buttons.isEmpty()) {
                System.out.println("No expired policies found in list for: " + policyType);
                return true; // Pass test because no expired policies is valid case
            }

            WebElement button = buttons.get(0);
            if (button.isDisplayed()) {
                button.click();
            } else {
                System.out.println("Renewal button not visible for policyType: " + policyType);
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error while finding renewal button: " + e.getMessage());
            return false;
        }

        // Step 2: After clicking, check if the renewal button disappears
        try {
            boolean stillVisible = getElement(renewalButton).isDisplayed();
            if (!stillVisible) {
                System.out.println("Successfully renewed policy: " + policyType);
                return true;
            } else {
                System.out.println("Renewal button still visible. Renewal may have failed.");
                return false;
            }
        } catch (Exception e) {
            // If element is not found anymore, that's success
            System.out.println("Successfully renewed policy: " + policyType);
            return true;
        }
    }

    public boolean isUserAbleTOCreateTheClaim(String policyType,String status,String coverageAmount) {
        By createClaimLocatorButton = By.xpath(createClaimLocator.replace("@@", policyType).replace("##", status));

        viewPolicyNavigation();

        try {
            WebElement button = getElement(createClaimLocatorButton);
            if (button.isDisplayed()) {
                button.click();
            } else {
                System.out.println("createClaim button not visible for policyType: " + policyType);
                return false;
            }
        } catch (Exception e) {
            System.out.println("createClaim button not found initially: " + e.getMessage());
            return false;
        }

        WebElement coverageAmountField=getElement(coverageAmountLocator);
        coverageAmountField.sendKeys(coverageAmount);

        getElement(submitClaimLocator).click();

        return true;

    }

    public boolean isUserRestrictedWhenClaimAmountExceedsCoverage(String policyType, String status, String coverageAmount, String greaterAmount) {
        By createClaimLocatorButton = By.xpath(createClaimLocator.replace("@@", policyType).replace("##", status));

        viewPolicyNavigation();

        try {
            WebElement button = getElement(createClaimLocatorButton);
            if (button.isDisplayed()) {
                button.click();
            } else {
                System.out.println("CreateClaim button not visible for policyType: " + policyType);
                return false;
            }
        } catch (Exception e) {
            System.out.println("CreateClaim button not found initially: " + e.getMessage());
            return false;
        }

        // Enter amount greater than allowed coverage
        WebElement coverageAmountField = getElement(coverageAmountLocator);
        coverageAmountField.clear();
        coverageAmountField.sendKeys(greaterAmount);

        getElement(submitClaimLocator).click();

        // Now check if system blocked it
        try {
            // Assuming an error message is shown (adjust locator as per your UI)
            By errorMessageLocator = By.xpath("//div[text()='Claim amount cannot exceed the policy coverage.']");
            WebElement errorMsg = getElement(errorMessageLocator);
            if (errorMsg.isDisplayed()) {
                System.out.println("Validation worked: system blocked amount greater than coverage");
                return true; // Test should pass
            }
        } catch (Exception e) {
            // No error message found → check if form closed or claim accepted
            System.out.println("No validation message displayed, claim may have been accepted with greater amount ❌");
            return false; // Test should fail
        }

        return false; // Default → fail
    }

    public String TrackTheStatus(String policyType){
        viewClaimsNavigation();
        By statusLocator=By.xpath(policyStatus.replace("@@",policyType));
        String text=getElement(statusLocator).getText();

        System.out.println(text);
        return text;
    }

}
