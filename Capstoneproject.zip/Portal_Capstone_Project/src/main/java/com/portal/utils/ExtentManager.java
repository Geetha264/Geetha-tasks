package com.portal.utils;


import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentManager {
    private static ExtentReports extent;

    public static ExtentReports getInstance() {
        if (extent == null) {
            // Create timestamp for each test run
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());

            // Save reports inside "test-output/reports" folder
            String reportPath = System.getProperty("user.dir")
                    + "/test-output/reports/ExtentReport_"
                    + timestamp + ".html";

            ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);
            spark.config().setDocumentTitle("Automation Test Report");
            spark.config().setReportName("Execution Results - " + timestamp);

            extent = new ExtentReports();
            extent.attachReporter(spark);
        }
        return extent;
    }
}
