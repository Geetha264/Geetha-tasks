package com.portal.utils;

public class LoggerUtil {
}
