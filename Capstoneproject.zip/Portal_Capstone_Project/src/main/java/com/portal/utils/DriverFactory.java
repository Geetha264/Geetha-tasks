package com.portal.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.edge.EdgeDriver;

// Optional: WebDriverManager makes it easier to manage browser driver binaries.
// If you have io.github.bonigarcia:webdrivermanager on your pom, uncomment imports & setup lines below.
// import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverFactory {

    /**
     * Existing no-arg method (kept as-is) that reads browser from config.
     */
    public static WebDriver createDriver() {
        String browser = ConfigReader.getProperty("browser").toLowerCase();
        return createDriver(browser);
    }

    /**
     * New overload: create driver based on provided browser name.
     * If browser is null/blank, it will fall back to ConfigReader (via createDriver()).
     */
    public static WebDriver createDriver(String browser) {
        if (browser == null || browser.isBlank()) {
            // Delegate to existing behaviour (reads from config)
            return createDriver();
        }

        String b = browser.trim().toLowerCase();

        switch (b) {
            case "chrome":
                // Optional WebDriverManager usage:
                // WebDriverManager.chromedriver().setup();
                return new ChromeDriver();

            case "firefox":
            case "mozilla":
                // WebDriverManager.firefoxdriver().setup();
                return new FirefoxDriver();

            case "edge":
            case "msedge":
                // WebDriverManager.edgedriver().setup();
                return new EdgeDriver();

            default:
                // If unknown browser string, throw a helpful message (keeps behavior strict)
                throw new IllegalArgumentException("Browser not supported: " + browser);
        }
    }
}
