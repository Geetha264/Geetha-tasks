package com.portal.utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;

public class ExcelUtils {

    public static Object[][] getSheetData(String filePath, String sheetName) throws IOException {
        FileInputStream fis = new FileInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheet(sheetName);

        int rowCount = sheet.getLastRowNum(); // last row index (header excluded)
        int colCount = sheet.getRow(0).getLastCellNum(); // total columns

        Object[][] data = new Object[rowCount][colCount];
        DataFormatter formatter = new DataFormatter();

        // Start from row 1 (skip header)
        for (int i = 1; i <= rowCount; i++) {
            Row row = sheet.getRow(i);
            for (int j = 0; j < colCount; j++) {
                Cell cell = row.getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                data[i - 1][j] = formatter.formatCellValue(cell); // keeps everything as String
            }
        }

        workbook.close();
        fis.close();
        return data;
    }
}
