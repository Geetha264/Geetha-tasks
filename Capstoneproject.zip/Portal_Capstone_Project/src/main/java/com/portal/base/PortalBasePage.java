package com.portal.base;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class PortalBasePage {

    protected WebDriver driver;
    protected WebDriverWait wait;
    protected Actions actions;

    public PortalBasePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        this.actions = new Actions(driver);
    }

    // Highlight Element (Reusable)
    protected WebElement highlightElement(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].style.border='3px solid blue'", element);
        return element;
    }

    // Get Element (with wait + highlight)
    protected WebElement getElement(By locator) {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        return highlightElement(element);
    }

    // Click Element
    public void click(By locator) {
        getElement(locator).click();
    }

    // Enter Text
    public void type(By locator, String text) {
        WebElement el = getElement(locator);
        el.clear();
        el.sendKeys(text);
    }

    // Get Text
    public String getText(By locator) {
        return getElement(locator).getText();
    }

    // Wait for element clickable
    public void waitForClickable(By locator) {
        wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    // Scroll into view
    public void scrollIntoView(By locator) {
        WebElement element = getElement(locator);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }

    // Get today's date in desired format
    public static String getCurrentDate(String pattern) {
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return today.format(formatter);
    }

    // Get date + time in desired format
    public static String getCurrentDateTime(String pattern) {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return now.format(formatter);
    }

    // Get current time in desired format
    public static String getCurrentTime(String pattern) {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return now.format(formatter);
    }

    // Get current time in HHmmSSS (hour, minute, milliseconds)
    public static String getCurrentTimeWithMillis() {
        SimpleDateFormat sdf = new SimpleDateFormat("HHmmssSSS");
        return sdf.format(new Date());
    }

    // Take Screenshot (returns path)
    public String takeScreenshot(String fileName) {
        String filePath = System.getProperty("user.dir") + "/reports/screenshots/" + fileName + ".png";
        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            byte[] src = ts.getScreenshotAs(OutputType.BYTES);
            java.nio.file.Files.write(java.nio.file.Paths.get(filePath), src);
        } catch (Exception e) {
            System.out.println("Screenshot failed: " + e.getMessage());
        }
        return filePath;
    }

    // 🔹 Dropdowns
    protected void selectByVisibleText(By locator, String text) {
        Select dropdown = new Select(getElement(locator));
        dropdown.selectByVisibleText(text);
    }

    protected void selectByValue(By locator, String value) {
        Select dropdown = new Select(getElement(locator));
        dropdown.selectByValue(value);
    }

    protected void selectByIndex(By locator, int index) {
        Select dropdown = new Select(getElement(locator));
        dropdown.selectByIndex(index);
    }

    // 🔹 Mouse & keyboard actions
    protected void hoverOver(By locator) {
        actions.moveToElement(getElement(locator)).perform();
    }

    protected void doubleClick(By locator) {
        actions.doubleClick(getElement(locator)).perform();
    }

    protected void rightClick(By locator) {
        actions.contextClick(getElement(locator)).perform();
    }

    protected void dragAndDrop(By source, By target) {
        actions.dragAndDrop(getElement(source), getElement(target)).perform();
    }

    // 🔹 Waits
    protected void waitForVisibility(By locator) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    protected void waitForInvisibility(By locator) {
        wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }

    protected void waitForPageTitle(String title) {
        wait.until(ExpectedConditions.titleContains(title));
    }

    // 🔹 JS Executor helpers
    protected void scrollToElement(By locator) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", getElement(locator));
    }

    protected void clickWithJS(By locator) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", getElement(locator));
    }

    protected void setValueWithJS(By locator, String value) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='" + value + "';", getElement(locator));
    }

    // 🔹 Alerts
    protected void acceptAlert() {
        wait.until(ExpectedConditions.alertIsPresent()).accept();
    }

    protected void dismissAlert() {
        wait.until(ExpectedConditions.alertIsPresent()).dismiss();
    }

    protected String getAlertText() {
        return wait.until(ExpectedConditions.alertIsPresent()).getText();
    }

    // 🔹 Frames
    protected void switchToFrame(By locator) {
        driver.switchTo().frame(getElement(locator));
    }

    protected void switchToDefaultContent() {
        driver.switchTo().defaultContent();
    }
}

