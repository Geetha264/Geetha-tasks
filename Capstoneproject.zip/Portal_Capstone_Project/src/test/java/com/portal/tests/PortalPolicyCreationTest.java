package com.portal.tests;

import com.portal.base.PortalBaseTest;
import com.portal.pages.PortalLoginPage;
import com.portal.pages.PortalNewPolicyCreationPage;
import com.portal.utils.ExcelUtils;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PortalPolicyCreationTest extends PortalBaseTest {

    @DataProvider(name = "policyData")
    public Object[][] getPolicyData() throws Exception {
        return ExcelUtils.getSheetData("src/test/resources/testdata/Policies_Data.xlsx", "Sheet1");
    }

    @Test(dataProvider = "policyData")
    public void testPolicyCreation(String PolicyName, String age, String Duration) {
        PortalNewPolicyCreationPage policy = new PortalNewPolicyCreationPage(getDriver());
        PortalLoginPage login=new PortalLoginPage(getDriver());
        login.homePageLogin();
        login.Login("Geethu_317","admin@123");
        boolean status=policy.createNewPolicy(PolicyName, age, Duration);
        Assert.assertTrue(status,"Account not created");
        logger.info("policy created successfully");

    }
}





