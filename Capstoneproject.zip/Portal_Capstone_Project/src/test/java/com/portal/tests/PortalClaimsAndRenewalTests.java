package com.portal.tests;

import com.portal.base.PortalBaseTest;
import com.portal.pages.PortalClaimsAndRenewalPage;
import com.portal.pages.PortalDashBoardPage;
import com.portal.pages.PortalLoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PortalClaimsAndRenewalTests extends PortalBaseTest {

    @Test(priority = 1, description = "Checking User is able to renewal the policy after it got Expire")
    public void isUserAbleToRenewPolicy() {
        PortalLoginPage login = new PortalLoginPage(getDriver());
        PortalClaimsAndRenewalPage renewal = new PortalClaimsAndRenewalPage(getDriver());
        login.homePageLogin();
        login.Login("Geethu_317", "admin@123");

        boolean status = renewal.isUserAbleToRenewalPolicy("Vehicle Insurance Policy", "Expired");
        Assert.assertTrue(status, "Policy renewal failed OR expired policies not handled properly");
    }

    @Test(priority = 2, description = "Checking that user is able to request the amount claim")
    public void isUserAbleToCreateClaim() {
        PortalLoginPage login = new PortalLoginPage(getDriver());
        PortalClaimsAndRenewalPage renewal = new PortalClaimsAndRenewalPage(getDriver());
        login.homePageLogin();
        login.Login("Geethu_317", "admin@123");

        boolean status = renewal.isUserAbleTOCreateTheClaim("Vehicle Insurance Policy", "Active", "10000");
        Assert.assertTrue(status, "User is not able to claim the request");
    }

    @Test(priority = 3, description = "Checking that system does not allow claim amount greater than coverage amount")
    public void verifyClaimCannotExceedCoverage() {
        PortalLoginPage login = new PortalLoginPage(getDriver());
        PortalClaimsAndRenewalPage claimsPage = new PortalClaimsAndRenewalPage(getDriver());
        login.homePageLogin();
        login.Login("Geethu_317", "admin@123");

        String policyType = "Health Insurance";
        String status = "Active";
        String coverageAmount = "500000";   // Suppose coverage = 500000
        String greaterAmount = "7000000";   // Send greater than coverage

        boolean result = claimsPage.isUserRestrictedWhenClaimAmountExceedsCoverage(
                policyType, status, coverageAmount, greaterAmount);
        Assert.assertTrue(result, "System incorrectly allowed claim greater than coverage!");
    }

    @Test(priority = 4, description = "Tracking the status of policy after raising the claim")
    public void policyStatusTracking() {
        PortalLoginPage login = new PortalLoginPage(getDriver());
        PortalClaimsAndRenewalPage claimsPage = new PortalClaimsAndRenewalPage(getDriver());
        PortalDashBoardPage dash = new PortalDashBoardPage(getDriver());
        login.homePageLogin();
        login.Login("Geethu_317", "admin@123");

        String policyType = "Health Insurance";
        boolean status = claimsPage.isUserAbleTOCreateTheClaim(policyType, "Active", "10000");
        Assert.assertTrue(status, "Policy not created");

        dash.dashBoardNavigation();
        claimsPage.TrackTheStatus(policyType);
    }
}
