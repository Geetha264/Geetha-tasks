package com.portal.tests;

import com.portal.base.PortalBaseTest;
import com.portal.pages.PortalRegisterNewUserPage;

import org.testng.Assert;
import org.testng.annotations.Test;

public class PortalNewUserRegistrationTest extends PortalBaseTest {



    @Test(priority = 1,description = "New user creation")
    public void newUserRegistrationValidation(){
        PortalRegisterNewUserPage page = new PortalRegisterNewUserPage(getDriver());
        String ts = PortalRegisterNewUserPage.getCurrentTimeWithMillis();
        String username = "Geethu_317" + ts;
        String email = "bgeetha" + ts + "@gmail.com";
        boolean status = page.registerNewCustomer(username, email, "Solutions@9398");
        Assert.assertTrue(status, "Account not created");
        logger.info("account created successfully");
    }

    @Test(priority =2,description = "User is registering with invalid email")
    public void register_withInvalidEmail_shouldShowValidation() {
        PortalRegisterNewUserPage page = new PortalRegisterNewUserPage(getDriver());
        String ts = PortalRegisterNewUserPage.getCurrentTimeWithMillis();
        String username = "user_" + ts;
        boolean error = page.registerAndReturnIfValidationError(username, "invalidEmail", "Solutions@9398", "Solutions@9398");
        Assert.assertTrue(error, "Expected validation error for invalid email");
    }

    @Test(priority = 3,description = "registering with password mismatching")
    public void register_whenPasswordMismatch_shouldFail() {
        PortalRegisterNewUserPage page = new PortalRegisterNewUserPage(getDriver());
        String ts = PortalRegisterNewUserPage.getCurrentTimeWithMillis();
        String username = "user_" + ts;
        String email = "user" + ts + "@gmail.com";
        boolean error = page.registerAndReturnIfValidationError(username, email, "Solutions@9398", "Different@123");
        Assert.assertTrue(error, "Expected validation error for password mismatch");
    }

    @Test(priority = 4,description = "Click Register with out details")
    public void register_withEmptyFields_shouldShowErrors() {
        PortalRegisterNewUserPage page = new PortalRegisterNewUserPage(getDriver());
        boolean anyValidation = page.clickSubmitWithoutFillingAndDetectValidation();
        Assert.assertTrue(anyValidation, "Expected validation messages when submitting empty form");
    }

    @Test(priority = 5,description = "Register with duplicate email")
    public void register_withDuplicateEmail_shouldShowAlreadyExists() throws InterruptedException {
        PortalRegisterNewUserPage page = new PortalRegisterNewUserPage(getDriver());
        String ts = PortalRegisterNewUserPage.getCurrentTimeWithMillis();
        String email = "geetha" + ts + "@gmail.com";

        // 1) Create first user
        boolean first = page.registerNewCustomer("geetha" + ts, email, "Test@9398");
        Assert.assertTrue(first, "Initial account creation failed");
        Thread.sleep(6000);
        // 2) Try again with same email
        boolean duplicate = page.registerAndReturnIfAlreadyExists("geetha2" + ts, email, "Test@9398");
        Assert.assertTrue(duplicate, "Expected duplicate email error");
    }


}
