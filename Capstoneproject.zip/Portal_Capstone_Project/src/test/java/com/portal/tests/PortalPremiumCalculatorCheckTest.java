package com.portal.tests;

import com.portal.base.PortalBaseTest;
import com.portal.pages.PortalLoginPage;
import com.portal.pages.PortalPremiumCalculatorPage;

import org.testng.Assert;
import org.testng.annotations.Test;

public class PortalPremiumCalculatorCheckTest extends PortalBaseTest {


    @Test(priority = 1,description = "checking the premium for Policies")
    public void userIsAbleToCalculateThePremium(){
        PortalLoginPage login=new PortalLoginPage(getDriver());
        PortalPremiumCalculatorPage calculator=new PortalPremiumCalculatorPage(getDriver());
        login.homePageLogin();
        login.Login("Geethu_317","admin@123");
        boolean status=calculator.calculatePremium("Vehicle Insurance Policy","22","3");
        Assert.assertTrue(status,"premium not calculated");
    }

    @Test(priority = 2,description = "checking that system is allowing with higher age to calculate the premium")
    public void is_user_able_ToCalculateWith_HigherAge(){
        PortalLoginPage login=new PortalLoginPage(getDriver());
        PortalPremiumCalculatorPage calculator=new PortalPremiumCalculatorPage(getDriver());
        login.homePageLogin();
        login.Login("Geethu_317","admin@123");
        boolean status=calculator.calculatePremiumWithGreaterAge("Vehicle Insurance Policy","268","2");
        Assert.assertFalse(status, "Premium calculation failed for greater age input");


    }
}
