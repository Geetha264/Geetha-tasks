package com.portal.tests;


import com.portal.base.PortalBaseTest;
import com.portal.listeners.TestListener;
import com.portal.pages.PortalNewPolicyCreationPage;
import com.portal.pages.PortalLoginPage;
import com.portal.utils.ExcelUtils;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(TestListener.class)
public class PortalLoginValidations extends PortalBaseTest {

    @Test(priority = 1,
            description = "Verify login functionality with default credentials",
            groups = {"smoke", "regression"}
    )
    public void loginWithDefaultCredentials() throws InterruptedException {
        PortalLoginPage login = new PortalLoginPage(getDriver());
        login.homePageLogin();
        login.Login("Geethu_317", "admin@123");

        getTest().info("Successfully logged in with default credentials");
        logger.info("Successfully logged in with default credentials");

        boolean status = login.isLoginSuccessFull();
        Assert.assertTrue(status, "Login failed for default user");
    }

    @DataProvider(name = "Test")
    public Object[][] getLoginData() throws Exception {
        String excelPath = "src/test/resources/testdata/Test.xlsx";
        return ExcelUtils.getSheetData(excelPath, "Sheet1");
    }

    @Test(priority = 2,
            dataProvider = "Test",
            description = "Verify login functionality with multiple sets of credentials from Excel",
            groups = {"regression"}
    )
    public void loginWithValidAndInvalidDataByExcelData(String Username, String Password, String ExpectedResult) throws InterruptedException {
        PortalLoginPage login=new PortalLoginPage(getDriver());
        login.homePageLogin();
        login.Login(Username, Password);

        boolean status = login.isLoginSuccessFull();

        if (ExpectedResult.equalsIgnoreCase("Valid")) {
            Assert.assertTrue(status, "Login failed for valid user: " + Username);
        } else if (ExpectedResult.equalsIgnoreCase("Invalid")) {
            Assert.assertFalse(status, "Login passed for invalid user: " + Username);
        }

        getTest().info("Login test executed for user: " + Username);
        logger.info("Login test executed for user: " + Username);
    }


    @Test(priority = 3, description="Username empty")
    public void login_withUsernameEmpty_shouldShowValidation() {
        PortalLoginPage login = new PortalLoginPage(getDriver());
        login.homePageLogin();
        login.Login("", "somePassword");
        Assert.assertFalse(login.isLoginSuccessFull());
    }

    @Test(priority = 4, description="Password empty")
    public void login_withPasswordEmpty_shouldShowValidation() {
        PortalLoginPage login = new PortalLoginPage(getDriver());
        login.homePageLogin();
        login.Login("Geethu_317", "");
        Assert.assertFalse(login.isLoginSuccessFull());
    }

    @Test(priority = 5, description="Username case sensitivity")
    public void login_usernameCaseSensitivity() {
        PortalLoginPage login = new PortalLoginPage(getDriver());
        login.homePageLogin();
        // If actual username is 'geethu_317'
        login.Login("geethu_317", "admin@123");
        boolean status = login.isLoginSuccessFull();
        // decide expected: if usernames are case-insensitive, should pass.
        // Here assert false as conservative default:
        Assert.assertFalse(status, "Username case-sensitivity should be enforced unless system defines otherwise");
    }




}
