package com.portal.tests;

import com.portal.base.PortalBaseTest;
import com.portal.pages.PortalLoginPage;
import com.portal.pages.PortalPaymentPage;

import org.testng.Assert;
import org.testng.annotations.Test;

public class PortalPaymentTest extends PortalBaseTest {

    private void performLogin() {
        PortalLoginPage login = new PortalLoginPage(getDriver());
        login.homePageLogin();
        login.Login("Geethu_317", "admin@123");
    }

    @Test(priority = 1, description = "Checking if user is able to do the payment for Home Insurance")
    public void PaymentValidationForHomeInsurance() {
        performLogin();
        PortalPaymentPage payment = new PortalPaymentPage(getDriver());

        boolean status = payment.payPremium("Home Insurance", "Pending");

        if(status) {
            System.out.println("Payment test passed for Home Insurance");
            Assert.assertTrue(true);
        } else {
            System.out.println("Payment not done, test failed for Home Insurance");
            Assert.assertTrue(false, "Payment failed for Home Insurance");
        }
    }

    @Test(priority = 2, description = "Checking if user is able to do payment for Health Insurance")
    public void PaymentValidationForHealthInsurance() {
        performLogin();
        PortalPaymentPage payment = new PortalPaymentPage(getDriver());

        boolean status = payment.payPremium("Individual Health Insurance", "Pending");

        if(status) {
            System.out.println("Payment test passed for Health Insurance");
            Assert.assertTrue(true);
        } else {
            System.out.println("Payment not done, test failed for Health Insurance");
            Assert.assertTrue(false, "Payment failed for Health Insurance");
        }
    }
}
