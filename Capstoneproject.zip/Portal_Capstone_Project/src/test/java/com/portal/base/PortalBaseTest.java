package com.portal.base;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.portal.utils.ConfigReader;
import com.portal.utils.DriverFactory;
import com.portal.utils.ExtentManager;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import java.lang.reflect.Method;
import java.time.Duration;

public class PortalBaseTest {
    private static final ThreadLocal<WebDriver> driver = new ThreadLocal<>();
    private static final ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();
    private static ExtentReports extent;
    public static final Logger logger = LogManager.getLogger(PortalBaseTest.class);

    @BeforeSuite(alwaysRun = true)
    public void setupReport() {
        extent = ExtentManager.getInstance();
    }

    /**
     * Minimal safe change: accept optional TestNG parameter "browser".
     * If provided, the DriverFactory should have an overloaded createDriver(browser) method.
     * If not provided, we fall back to the no-arg createDriver() you already have.
     */
    @Parameters("browser")
    @BeforeMethod(alwaysRun = true)
    public void setup(@Optional String browser, Method method) {
        WebDriver d;

        // If browser param passed from testng.xml or -Dbrowser, use it. Otherwise use default factory behavior.
        if (browser != null && !browser.isBlank()) {
            // If you don't already have this overload in DriverFactory, add it:
            // public static WebDriver createDriver(String browser) { ... }
            d = DriverFactory.createDriver(browser);
            logger.info("Starting test '" + method.getName() + "' on browser: " + browser);
        } else {
            d = DriverFactory.createDriver(); // existing behavior
            logger.info("Starting test '" + method.getName() + "' on default browser from DriverFactory/config.");
        }

        driver.set(d);
        getDriver().manage().window().maximize();

        ExtentTest test = extent.createTest(method.getName());
        extentTest.set(test);

        // navigate to baseURL and set implicit wait if present in config
        String baseUrl = ConfigReader.getProperty("baseUrl");
        if (baseUrl != null && !baseUrl.isBlank()) {
            getDriver().get(baseUrl);
        }

        String waitStr = ConfigReader.getProperty("implicitWait");
        try {
            int wait = (waitStr != null && !waitStr.isBlank()) ? Integer.parseInt(waitStr) : 500;
            getDriver().manage().timeouts().implicitlyWait(Duration.ofMillis(wait));
        } catch (NumberFormatException e) {
            logger.warn("Invalid implicitWait value in config; defaulting to 500ms", e);
            getDriver().manage().timeouts().implicitlyWait(Duration.ofMillis(500));
        }
    }

    public WebDriver getDriver() {
        return driver.get();
    }

    public ExtentTest getTest() {
        return extentTest.get();
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        try {
            WebDriver wd = getDriver();
            if (wd != null) {
                wd.quit();
            }
        } catch (Exception e) {
            logger.warn("Error during driver.quit()", e);
        } finally {
            // Important: remove ThreadLocal references to avoid memory leaks in long running suites
            driver.remove();
            extentTest.remove();
        }
    }

    @AfterSuite(alwaysRun = true)
    public void flushReport() {
        if (extent != null) {
            extent.flush();
        }
    }
}
