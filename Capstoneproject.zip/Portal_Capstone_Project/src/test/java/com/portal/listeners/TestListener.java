package com.portal.listeners;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.portal.base.PortalBaseTest;
import com.portal.utils.ScreenshotUtils;
import com.aventstack.extentreports.ExtentTest;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class TestListener implements ITestListener {

    @Override
    public void onTestFailure(ITestResult result) {
        Object testObj = result.getInstance();

        if (testObj instanceof PortalBaseTest) {
            PortalBaseTest base = (PortalBaseTest) testObj;
            ExtentTest test = base.getTest();

            if (test != null) {
                test.fail(result.getThrowable());

                try {
                    String path = ScreenshotUtils.captureScreenshot(base.getDriver());
                    test.fail("Screenshot of failure",
                            MediaEntityBuilder.createScreenCaptureFromPath(path).build());
                } catch (Exception e) {
                    test.warning("Could not capture screenshot: " + e.getMessage());
                }
            }
        }
    }

//    @Override
//    public void onTestSuccess(ITestResult result) {
//        if (result.getInstance() instanceof BaseTest) {
//            BaseTest base = (BaseTest) result.getInstance();
//            ExtentTest test = base.getTest();
//
//            if (test != null) {
//                test.pass("Test Passed");
//
//                try {
//                    String path = ScreenshotUtils.captureScreenshot(base.getDriver());
//                    test.pass("Screenshot of success",
//                            MediaEntityBuilder.createScreenCaptureFromPath(path).build());
//                } catch (Exception e) {
//                    test.warning("Could not capture screenshot on success: " + e.getMessage());
//                }
//            }
//        }
//    }

        @Override
    public void onTestSuccess(ITestResult result) {
        if (result.getInstance() instanceof PortalBaseTest) {
            ((PortalBaseTest) result.getInstance()).getTest().pass("Test Passed");
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        if (result.getInstance() instanceof PortalBaseTest) {
            ((PortalBaseTest) result.getInstance()).getTest().skip("Test Skipped: " + result.getThrowable());
        }
    }

    @Override public void onStart(ITestContext context) {}
    @Override public void onFinish(ITestContext context) {}
}

