# Insurance Complete Automation Project

This project is a complete end-to-end Selenium + TestNG + POM framework with Excel-driven tests.

## How to run locally
1. Import as Maven project.
2. Ensure Java 11+ and Chrome installed.
3. Run `mvn test` or execute `testng.xml` from IDE.
4. Test data in `testdata/InsuranceData.xlsx`.
5. Reports: `reports/ExtentReport.html`. Screenshots in `/screenshots`.

## Jenkins
Use the provided Jenkinsfile to run in CI.
