package com.capstone.utils;

import org.apache.poi.ss.usermodel.*;
import java.io.FileInputStream;
import java.io.IOException;

public class ExcelUtils {

    public static Object[][] getTableArray(String filePath, String sheetName) {
        try (FileInputStream fis = new FileInputStream(filePath)) {
            Workbook workbook = WorkbookFactory.create(fis);
            Sheet sheet = workbook.getSheet(sheetName);

            int rowCount = sheet.getLastRowNum(); // exclude header
            int colCount = sheet.getRow(0).getLastCellNum();

            Object[][] data = new Object[rowCount][colCount];

            for (int i = 1; i <= rowCount; i++) { // start from 1 to skip header
                Row row = sheet.getRow(i);
                for (int j = 0; j < colCount; j++) {
                	Cell cell = row.getCell(j);
                	if (cell == null) {
                	    data[i-1][j] = "";
                	} else {
                	    cell.setCellType(CellType.STRING); // force as string
                	    data[i-1][j] = cell.getStringCellValue();
                	}
                }
            }
            return data;

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
