package com.capstone.utils;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebDriverFactory {
    public static WebDriver create(String browser) {
        if (browser == null) browser = "chrome";
        switch (browser.toLowerCase()) {
            case "firefox": WebDriverManager.firefoxdriver().setup(); return new FirefoxDriver();
            case "chrome": default: WebDriverManager.chromedriver().setup(); return new ChromeDriver();
        }
    }
}
