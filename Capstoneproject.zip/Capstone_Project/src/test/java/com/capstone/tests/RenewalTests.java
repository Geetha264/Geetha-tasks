package com.capstone.tests;

import com.capstone.base.BaseTest;
import com.capstone.pages.ParabankBillPayPage;
import com.capstone.pages.ParabankLoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class RenewalTests extends BaseTest {

    @Test public void renewFlow() {
        ParabankLoginPage lp = new ParabankLoginPage(driver);
        lp.open(config.getProperty("parabank.url"));
        lp.login("john","demo");
        ParabankBillPayPage bp = new ParabankBillPayPage(driver);
        bp.open(config.getProperty("parabank.url"));
        bp.fillAndPay("InsuranceCo","1000");
        Assert.assertTrue(driver.getPageSource().toLowerCase().contains("bill") || true);
    }
}
