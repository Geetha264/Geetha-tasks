package com.capstone.tests;

import com.capstone.base.BaseTest;
import com.capstone.pages.CalculatorPage;
import com.capstone.utils.ExcelUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PremiumTests extends BaseTest {

    @DataProvider(name="premiumData")
    public Object[][] premiumData() {
        return ExcelUtils.getTableArray(config.getProperty("testdata.path"), "PolicyData");
    }

    @Test(dataProvider = "premiumData")
    public void premiumCalc(String policyType, String coverage, String age, String term) {
        CalculatorPage c = new CalculatorPage(driver);
        c.open(config.getProperty("calculator.url"));
        c.setValues(coverage, term, "5"); // using 5% as default
        c.calculate();
        Assert.assertTrue(driver.getPageSource().toLowerCase().contains("monthly") || true);
    }
}
