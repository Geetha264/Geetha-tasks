package com.capstone.tests;

import com.capstone.base.BaseTest;
import com.capstone.pages.ParabankLoginPage;
import com.capstone.utils.ExcelUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class LoginTests extends BaseTest {

    @DataProvider(name="loginData")
    public Object[][] loginData() {
        String path = config.getProperty("testdata.path");
        return ExcelUtils.getTableArray(path, "LoginData");
    }

    @Test(dataProvider = "loginData")
    public void loginTest(String username, String password, String expected) {
        ParabankLoginPage p = new ParabankLoginPage(driver);
        p.open(config.getProperty("parabank.url"));
        p.login(username, password);
        boolean loggedIn = driver.getPageSource().contains("Accounts Overview") || driver.getPageSource().contains("Log Out");
        if ("valid".equalsIgnoreCase(expected)) {
            Assert.assertTrue(loggedIn, "Expected login to succeed for: " + username);
        } else {
            Assert.assertFalse(loggedIn, "Expected login to fail for: " + username);
        }
    }
}
