package com.capstone.tests;

import com.capstone.base.BaseTest;
import com.capstone.pages.DemoBlazePage;
import com.capstone.utils.ExcelUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.Arrays;

public class PaymentTests extends BaseTest {

    @DataProvider(name="paymentData")
    public Object[][] paymentData() {
        String excelPath = config.getProperty("testdata.path"); // path to your Excel
        Object[][] data = ExcelUtils.getTableArray(excelPath, "PaymentData");
        System.out.println("Excel Data: " + Arrays.deepToString(data)); // debug
        return data;
    }

    @Test(dataProvider = "paymentData")
    public void paymentFlow(String name, String cardNumber, String month, String year, String cvv, String expected) {

        DemoBlazePage d = new DemoBlazePage(driver);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

        // Open demo site
        d.open(config.getProperty("demoblaze.url"));

        // Open first product and add to cart
        d.openFirstProduct();
        d.addToCart();

        // Open cart
        d.openCart(config.getProperty("demoblaze.url"));

        // Wait for Place Order button and click
        WebElement placeOrderBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(text(),'Place Order')]")));
        placeOrderBtn.click();

        // Wait for modal content to appear
        WebElement modal = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(".modal-content")));

        // Debug print
        System.out.println("Filling payment for: " + name + ", Card: " + cardNumber + ", CVV: " + cvv);

        // Fill payment form inside modal
        modal.findElement(By.id("name")).sendKeys(name);
        modal.findElement(By.id("country")).sendKeys("India");
        modal.findElement(By.id("city")).sendKeys("City");
        modal.findElement(By.id("card")).sendKeys(cardNumber);
        modal.findElement(By.id("month")).sendKeys(month);
        modal.findElement(By.id("year")).sendKeys(year);
        modal.findElement(By.id("cvv")).sendKeys(cvv);

        // Click Purchase button inside modal
        modal.findElement(By.xpath(".//button[text()='Purchase']")).click();

        // Handle JS alert safely
        String alertText = "";
        try {
            alertText = wait.until(ExpectedConditions.alertIsPresent()).getText();
            System.out.println("Purchase alert: " + alertText);
            driver.switchTo().alert().accept();
        } catch (Exception e) {
            System.out.println("Alert not present! Payment may have failed.");
        }

        // Validate according to expected value
        if (expected.equalsIgnoreCase("valid")) {
            Assert.assertTrue(alertText.contains("Thank you for your purchase"),
                    "Expected success, but purchase failed!");
        } else if (expected.equalsIgnoreCase("invalid")) {
            Assert.assertFalse(alertText.contains("Thank you for your purchase"),
                    "Expected failure, but purchase succeeded!");
        }
    }
}
