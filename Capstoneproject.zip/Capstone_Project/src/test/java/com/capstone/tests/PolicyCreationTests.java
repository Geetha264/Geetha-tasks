package com.capstone.tests;

import com.capstone.base.BaseTest;
import com.capstone.pages.DemoBlazePage;
import com.capstone.utils.ExcelUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PolicyCreationTests extends BaseTest {

    @DataProvider(name="policyData")
    public Object[][] policyData() {
        return ExcelUtils.getTableArray(config.getProperty("testdata.path"), "PolicyData");
    }

    @Test(dataProvider = "policyData")
    public void createPolicy(String policyType, String coverage, String age, String term) {
        DemoBlazePage d = new DemoBlazePage(driver);
        d.open(config.getProperty("demoblaze.url"));
        d.openFirstProduct();
        d.addToCart();
        d.openCart(config.getProperty("demoblaze.url"));
        Assert.assertTrue(driver.getPageSource().toLowerCase().contains("cart"));
    }
}
