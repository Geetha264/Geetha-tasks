package com.capstone.tests;

import com.capstone.base.BaseTest;
import com.capstone.pages.ParabankLoginPage;
import com.capstone.pages.ParabankRequestLoanPage;
import com.capstone.utils.ExcelUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ClaimTests extends BaseTest {

    @DataProvider(name = "ClaimData")
    public Object[][] claimData() {
        return ExcelUtils.getTableArray(config.getProperty("testdata.path"), "ClaimData");
    }

    @Test(dataProvider = "ClaimData")
    public void submitClaim(String policyNumber, String claimReason, String claimAmount) {
        // Login Page
        ParabankLoginPage lp = new ParabankLoginPage(driver);
        lp.open(config.getProperty("parabank.url"));
        lp.login("john", "demo");   // ⚠️ Ideally take username/password also from Excel

        // Navigate to Request Loan Page
        ParabankRequestLoanPage loan = new ParabankRequestLoanPage(driver);
        loan.navigateToLoanPage();   // <-- Add this method in ParabankRequestLoanPage

        // Perform Loan/Claim request
        System.out.println("Submitting claim for Policy: " + policyNumber + 
                           ", Reason: " + claimReason + 
                           ", Amount: " + claimAmount);

        loan.requestLoan(claimAmount, "100"); // second param = downPayment or dummy

        // Validate result
        boolean isApproved = driver.getPageSource().toLowerCase().contains("approved");
        Assert.assertTrue(isApproved, "❌ Loan/Claim NOT approved for policy: " + policyNumber);
        System.out.println("✅ Claim processed successfully for policy: " + policyNumber);
    }
}
