package com.capstone.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ParabankLoginPage {
    private WebDriver driver;
    public ParabankLoginPage(WebDriver driver) { this.driver = driver; }
    private By user = By.name("username");
    private By pass = By.name("password");
    private By loginBtn = By.cssSelector("input[value='Log In']");

    public void open(String baseUrl) { driver.get(baseUrl + "/index.htm"); }
    public void login(String u, String p) { driver.findElement(user).clear(); driver.findElement(user).sendKeys(u); driver.findElement(pass).clear(); driver.findElement(pass).sendKeys(p); driver.findElement(loginBtn).click(); }
    public void logout() { if (driver.findElements(By.linkText("Log Out")).size()>0) driver.findElement(By.linkText("Log Out")).click(); }
}
