package com.capstone.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class DemoBlazePage {
    private WebDriver driver;
    public DemoBlazePage(WebDriver driver) { this.driver = driver; }
    public void open(String url) { driver.get(url); }
    public void openFirstProduct() { List<WebElement> products = driver.findElements(By.cssSelector(".hrefch")); if (!products.isEmpty()) products.get(0).click(); }
    public void addToCart() { if (driver.findElements(By.xpath("//a[text()='Add to cart']")).size()>0) { driver.findElement(By.xpath("//a[text()='Add to cart']")).click(); try { Thread.sleep(800); } catch (InterruptedException ignored) {} try { driver.switchTo().alert().accept(); } catch (Exception ignored) {} } }
    public void openCart(String baseUrl) { driver.get(baseUrl + "/cart.html"); }
}
