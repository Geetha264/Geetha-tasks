package com.capstone.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class CalculatorPage {
    private WebDriver driver;
    public CalculatorPage(WebDriver driver) { this.driver = driver; }
    public void open(String url) { driver.get(url); }
    public void setValues(String amount, String term, String rate) {
        ((JavascriptExecutor) driver).executeScript("document.getElementsByName('cloanamount')[0].value='"+amount+"';");
        ((JavascriptExecutor) driver).executeScript("document.getElementsByName('cloanterm')[0].value='"+term+"';");
        ((JavascriptExecutor) driver).executeScript("document.getElementsByName('cinterestrate')[0].value='"+rate+"';");
    }
    public void calculate() { try { if (driver.findElements(org.openqa.selenium.By.xpath("//input[@value='Calculate']")).size()>0) driver.findElement(org.openqa.selenium.By.xpath("//input[@value='Calculate']")).click(); } catch (Exception ignored) {} }
}
