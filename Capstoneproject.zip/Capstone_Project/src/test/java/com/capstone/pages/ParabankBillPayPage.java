package com.capstone.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ParabankBillPayPage {
    private WebDriver driver;
    public ParabankBillPayPage(WebDriver driver) { this.driver = driver; }
    public void open(String baseUrl) { driver.get(baseUrl + "/billpay.htm"); }
    public void fillAndPay(String payee, String amount) {
        driver.findElement(By.name("payeeName")).sendKeys(payee);
        driver.findElement(By.name("address.street")).sendKeys("Addr");
        driver.findElement(By.name("city")).sendKeys("City");
        driver.findElement(By.name("state")).sendKeys("ST");
        driver.findElement(By.name("zipCode")).sendKeys("400001");
        driver.findElement(By.name("phoneNumber")).sendKeys("9999999999");
        driver.findElement(By.name("accountNumber")).sendKeys("12345678");
        driver.findElement(By.name("verifyAccount")).sendKeys("12345678");
        driver.findElement(By.name("amount")).sendKeys(amount);
        driver.findElement(By.cssSelector("input[value='Send Payment']")).click();
    }
}
