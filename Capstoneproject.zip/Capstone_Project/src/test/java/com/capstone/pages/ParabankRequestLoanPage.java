package com.capstone.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ParabankRequestLoanPage {
    private WebDriver driver;

    // Locators
    private By loanAmount = By.id("amount");
    private By downPayment = By.id("downPayment");
    private By fromAccount = By.id("fromAccountId");
    private By applyNowBtn = By.cssSelector("input[value='Apply Now']");

    public ParabankRequestLoanPage(WebDriver driver) {
        this.driver = driver;
    }

    // Navigate to Request Loan page after login
    public void navigateToLoanPage() {
        driver.findElement(By.linkText("Request Loan")).click();
    }

    // Fill loan request form and submit
    public void requestLoan(String amount, String downPay) {
        driver.findElement(loanAmount).clear();
        driver.findElement(loanAmount).sendKeys(amount);

        driver.findElement(downPayment).clear();
        driver.findElement(downPayment).sendKeys(downPay);

        // Select the first available account
        driver.findElement(fromAccount).click();

        driver.findElement(applyNowBtn).click();
    }
}
