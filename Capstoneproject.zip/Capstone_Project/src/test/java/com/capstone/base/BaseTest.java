package com.capstone.base;

import com.capstone.utils.WebDriverFactory;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import java.io.InputStream;
import java.time.Duration;
import java.util.Properties;

public class BaseTest {
    public WebDriver driver;
    protected Properties config = new Properties();

    @BeforeClass(alwaysRun = true)
    @Parameters({"browser"})
    public void setup(@Optional("chrome") String browser) throws Exception {
        driver = WebDriverFactory.create(browser);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("config.properties")) {
            config.load(is);
        }
    }

    @AfterClass(alwaysRun = true)
    public void teardown() { if (driver != null) driver.quit(); }
}
