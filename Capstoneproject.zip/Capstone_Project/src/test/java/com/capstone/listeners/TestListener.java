package com.capstone.listeners;

import com.capstone.utils.ExtentManager;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class TestListener implements ITestListener {
    private static String SCREENSHOT_DIR = System.getProperty("user.dir") + "/screenshots";
    private static ExtentReports extent = ExtentManager.getInstance();
    private static Map<String, ExtentTest> tests = new HashMap<>();

    @Override public void onStart(ITestContext context) { try { Files.createDirectories(Paths.get(SCREENSHOT_DIR)); } catch (Exception e) {} }

    @Override public void onTestStart(ITestResult result) { tests.put(result.getName(), extent.createTest(result.getName())); }

    @Override public void onTestFailure(ITestResult result) {
        Object instance = result.getInstance();
        try {
            WebDriver driver = (WebDriver) instance.getClass().getField("driver").get(instance);
            if (driver != null) {
                File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
                String dest = SCREENSHOT_DIR + "/" + result.getName() + "_failed.png";
                Files.copy(src.toPath(), Paths.get(dest));
                tests.get(result.getName()).fail(result.getThrowable()).addScreenCaptureFromPath(dest);
            } else {
                tests.get(result.getName()).fail(result.getThrowable());
            }
        } catch (Exception e) {
            tests.get(result.getName()).fail(result.getThrowable());
        }
        extent.flush();
    }

    @Override public void onFinish(ITestContext context) { extent.flush(); }
    @Override public void onTestSuccess(ITestResult result) { tests.get(result.getName()).pass("Test passed"); extent.flush(); }
    @Override public void onTestSkipped(ITestResult result) { tests.get(result.getName()).skip("Skipped"); extent.flush(); }
    @Override public void onTestFailedButWithinSuccessPercentage(ITestResult result) {}
}
